﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Login : Form
    {
        DataBase database = new DataBase();

        public Login()
        {
            InitializeComponent();
            TextBox2.UseSystemPasswordChar = true;
            this.AcceptButton = button1;
        }

        private void guna2ToggleSwitch1_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2ToggleSwitch1.Checked)
                textBox2.UseSystemPasswordChar = false;
            else
                textBox2.UseSystemPasswordChar = true;
        }

        private void LoginFunction()
        {
            var loginUser = textBox1.Text;
            var passwordUser = textBox2.Text;

            if (string.IsNullOrWhiteSpace(loginUser))
            {
                MessageBox.Show("Ви не ввели логін користувача!", "Помилка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            else if (string.IsNullOrWhiteSpace(passwordUser))
            {
                MessageBox.Show("Ви не ввели пароль користувача!", "Помилка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string query = $"SELECT id_user, login_user, password_user FROM register WHERE login_user = '{loginUser}' AND password_user = '{passwordUser}'";
            SqlCommand command = new SqlCommand(query, database.GetConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count == 1)
            {
                MessageBox.Show("Вхід було виконано успішно!", "Успіх!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                MainForm form = new MainForm();
                form.ShowDialog();
            }
            else
            {
                MessageBox.Show("Такого аккаунту не існує!", "Аккаунту не існує!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Login_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoginFunction();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private class DataBase
        {
            public DataBase()
            {
            }

            internal SqlConnection GetConnection()
            {
                throw new NotImplementedException();
            }
        }

    }
}
