﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class Data
    {
        DataBase database = new DataBase();
        public int columnCountField = 0;

        public void LoadDataTables(DataGridView datagrid, string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName))
            {
                MessageBox.Show("Ім'я таблиці не може бути порожнім!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            datagrid.Rows.Clear();
            datagrid.Columns.Clear();

            try
            {
                database.Open();

                // Load column names
                SqlCommand command = new SqlCommand($"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{tableName}'", database.GetConnection());
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string columnName = reader["COLUMN_NAME"].ToString();
                    datagrid.Columns.Add(columnName, columnName);
                }
                reader.Close();

                // Load table data
                string query = $"SELECT * FROM {tableName}";
                SqlCommand dataCommand = new SqlCommand(query, database.GetConnection());
                SqlDataReader dataReader = dataCommand.ExecuteReader();

                while (dataReader.Read())
                {
                    object[] rowValues = new object[dataReader.FieldCount];
                    dataReader.GetValues(rowValues);
                    datagrid.Rows.Add(rowValues);
                }
                dataReader.Close();

                columnCountField = datagrid.Columns.Count;
                datagrid.Columns.Add("TableName", "TableName");

                if (datagrid.Rows.Count > 0)
                {
                    foreach (DataGridViewRow row in datagrid.Rows)
                    {
                        row.Cells[columnCountField].Value = tableName;
                    }
                    datagrid.Columns["TableName"].Visible = false;
                }
                else
                {
                    MessageBox.Show("Поля таблиці є пустими!", "Увага!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Сталася помилка під час завантаження даних: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                database.Close();
            }
        }
    }

    internal class DataBase
    {
        public DataBase()
        {
        }
    }
}
