﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Database
    {
        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-7BRU1MF\\SQLEXPRESS;Initial Catalog=Parking_CourseWork;Integrated Security=True"); // Рядок підключення до БД

        public void Open() // Метод відкриття БД
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void Close() // Метод закриття БД
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public SqlConnection GetConnection()
        {
            return connection;
        }

    }
}
