﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class DeviceReg : Form
    {
        public partial class DeviceReg : Form
        {
            DataBase database = new DataBase();

            public DeviceReg()
            {
                InitializeComponent();
                ClientComboBoxLoad();
            }

            private void ClientComboBoxLoad()
            {
                database.Open();

                try
                {
                    SqlCommand command = new SqlCommand("SELECT client_id, name FROM client", database.GetConnection());
                    SqlDataReader reader = command.ExecuteReader();

                    guna2ComboBox1.Items.Clear();

                    while (reader.Read())
                    {
                        string clientId = reader["client_id"].ToString();
                        string clientName = reader["name"].ToString();
                        guna2ComboBox1.Items.Add($"{clientId} - {clientName}");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка завантаження: {ex.Message}");
                }
                finally
                {
                    database.Close();
                }
            }

            private void btnClearFields_Click(object sender, EventArgs e)
            {
                guna2ComboBox1.SelectedItem = null;
                guna2TextBox1.Clear();
                guna2TextBox2.Clear();
                guna2TextBox3.Clear();
            }

            private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
            {
                this.Close();
            }

            private void btnRegisterDevice_Click(object sender, EventArgs e)
            {
                try
                {
                    if (guna2ComboBox1.SelectedItem != null && !string.IsNullOrEmpty(guna2TextBox1.Text) && !string.IsNullOrEmpty(guna2TextBox2.Text))
                    {
                        database.Open();
                        string deviceQuery = "INSERT INTO devices (client_id, serial_number, device_model, device_type) VALUES (@ClientId, @SerialNumber, @DeviceModel, @DeviceType)";
                        SqlCommand command = new SqlCommand(deviceQuery, database.GetConnection());
                        command.Parameters.AddWithValue("@ClientId", guna2ComboBox1.SelectedItem.ToString().Split(' ')[0]);
                        command.Parameters.AddWithValue("@SerialNumber", guna2TextBox1.Text);
                        command.Parameters.AddWithValue("@DeviceModel", guna2TextBox2.Text);
                        command.Parameters.AddWithValue("@DeviceType", guna2TextBox3.Text);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Пристрій успішно зареєстровано!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Заповніть всі необхідні поля для реєстрації пристрою!", "Помилка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Виникла помилка: " + ex);
                }
                finally
                {
                    database.Close();
                }
            }
        }

    }
}
