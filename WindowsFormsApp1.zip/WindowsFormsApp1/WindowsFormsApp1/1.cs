﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class _1 : Form
    {
        internal class SwitchStatus
        {
            DataBase database = new DataBase();

            private void ExecuteCommand(string query)
            {
                SqlCommand command = new SqlCommand(query, database.GetConnection());
                int updateRow = command.ExecuteNonQuery();
            }

            public void SwitchStatusQuery(int device_id, string device_status)
            {
                database.Open();
                try
                {
                    string query = "";
                    if (device_status == "Активний")
                    {
                        query = $"UPDATE devices SET status = 'Неактивний' WHERE device_id = {device_id}";
                    }
                    else if (device_status == "Неактивний")
                    {
                        query = $"UPDATE devices SET status = 'Активний' WHERE device_id = {device_id}";
                    }
                    ExecuteCommand(query);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка зміни статусу: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    database.Close();
                }
            }
        }

    }
}
