﻿namespace WindowsFormsApp1
{
    internal class MainForm
    {
        public MainForm()
        {
        }
    }
}