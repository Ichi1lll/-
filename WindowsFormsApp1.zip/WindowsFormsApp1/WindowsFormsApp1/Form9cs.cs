﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form9cs : Form
    {
        private void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            database.Open();

            if (guna2DataGridView1.Columns[0].HeaderText != "package_id")
            {
                if (guna2DataGridView1.Columns.Count != 0)
                {
                    if (guna2DataGridView1.SelectedRows.Count > 0 && guna2DataGridView1.Columns[0].HeaderText == "device_id")
                    {
                        DeleteFunction("device_id", "devices");
                    }
                    else if (guna2DataGridView1.SelectedRows.Count > 0 && guna2DataGridView1.Columns[0].HeaderText == "client_id")
                    {
                        DeleteFunction("client_id", "clients");
                    }
                    else if (guna2DataGridView1.SelectedRows.Count > 0 && guna2DataGridView1.Columns[0].HeaderText == "contract_id")
                    {
                        DeleteContracts("contract_id", "contracts");
                    }
                    else if (guna2DataGridView1.SelectedRows.Count > 0 && guna2DataGridView1.Columns[0].HeaderText == "payment_id")
                    {
                        DeleteFunction("payment_id", "payments");
                    }
                    else
                    {
                        MessageBox.Show("Ви не обрали рядок таблиці!");
                    }
                }
            }
            else
            {
                MessageBox.Show("У вас немає доступу для видалення пакетів послуг!");
            }
            database.Close();
        }

    }
}
