﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class contactreg : Form
    {
        public contactreg()
        {
            InitializeComponent();
        }
        public partial class ContractReg : Form
        {
            DataBase database = new DataBase();

            public ContractReg()
            {
                InitializeComponent();
                ClientComboBoxLoad();
                PackageComboBoxLoad();
                guna2DateTimePicker1.CustomFormat = "dd.MM.yyyy HH:mm";
                guna2DateTimePicker2.CustomFormat = "dd.MM.yyyy HH:mm";
                guna2DateTimePicker1.MinDate = DateTime.Now;
                guna2DateTimePicker2.MinDate = DateTime.Now;
            }

            private void ClientComboBoxLoad()
            {
                database.Open();

                try
                {
                    SqlCommand command = new SqlCommand("SELECT client_id, name FROM client", database.GetConnection());
                    SqlDataReader reader = command.ExecuteReader();

                    guna2ComboBox1.Items.Clear();

                    while (reader.Read())
                    {
                        string clientId = reader["client_id"].ToString();
                        string clientName = reader["name"].ToString();
                        guna2ComboBox1.Items.Add($"{clientId} - {clientName}");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка завантаження: {ex.Message}");
                }
                finally
                {
                    database.Close();
                }
            }

            private void PackageComboBoxLoad()
            {
                database.Open();

                try
                {
                    SqlCommand command = new SqlCommand("SELECT package_id, package_name FROM packages", database.GetConnection());
                    SqlDataReader reader = command.ExecuteReader();

                    guna2ComboBox2.Items.Clear();

                    while (reader.Read())
                    {
                        string packageId = reader["package_id"].ToString();
                        string packageName = reader["package_name"].ToString();
                        guna2ComboBox2.Items.Add($"{packageId} - {packageName}");
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка завантаження: {ex.Message}");
                }
                finally
                {
                    database.Close();
                }
            }

            private void btnClearFields_Click(object sender, EventArgs e)
            {
                guna2ComboBox1.SelectedItem = null;
                guna2ComboBox2.SelectedItem = null;
                guna2TextBox1.Clear();
            }

            private void btnRegisterContract_Click(object sender, EventArgs e)
            {
                try
                {
                    if (guna2ComboBox1.SelectedItem != null && guna2ComboBox2.SelectedItem != null && !string.IsNullOrEmpty(guna2TextBox1.Text))
                    {
                        database.Open();

                        string contractQuery = "INSERT INTO contracts (client_id, package_id, contract_start_date, contract_end_date, monthly_fee) " +
                                               "VALUES (@ClientId, @PackageId, @StartDate, @EndDate, @MonthlyFee)";

                        SqlCommand command = new SqlCommand(contractQuery, database.GetConnection());
                        command.Parameters.AddWithValue("@ClientId", guna2ComboBox1.SelectedItem.ToString().Split(' ')[0]);
                        command.Parameters.AddWithValue("@PackageId", guna2ComboBox2.SelectedItem.ToString().Split(' ')[0]);
                        command.Parameters.AddWithValue("@StartDate", guna2DateTimePicker1.Value);
                        command.Parameters.AddWithValue("@EndDate", guna2DateTimePicker2.Value);
                        command.Parameters.AddWithValue("@MonthlyFee", decimal.Parse(guna2TextBox1.Text));
                        command.ExecuteNonQuery();

                        MessageBox.Show("Контракт успішно зареєстровано!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Заповніть всі необхідні поля для реєстрації контракту!", "Помилка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Виникла помилка: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    database.Close();
                }
            }

            private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
            {
                this.Close();
            }
        }

    }
}
